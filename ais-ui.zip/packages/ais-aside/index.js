import AisAside from './ais-aside.vue';

AisAside.install = function(Vue) {
    Vue.component(AisAside.name, AisAside);
}

export default AisAside;