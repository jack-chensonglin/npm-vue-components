<template>
    <div class="ais-aside">
        <el-menu :default-active="$router.path" router class="el-menu-vertical-demo" background-color="white"
            text-color="black" active-text-color="#50A9FF" @open="handleOpen" @close="handleClose"
            :collapse="isCollapse">
            <!-- <div class="logo-image">
          <el-image :src="url" fit="scale-down"></el-image>
        </div> <hr> -->
            <div v-for="item in routerArray" :key="item.cnName">
                <el-menu-item v-if="item.children.length == 0" :index="item.cnName">
                    <i :class="item.icon + ' ais-aside-icon-self'"></i>
                    <span slot="title">{{item.cnName}}</span>
                </el-menu-item>
                <el-submenu v-else :key="item.cnName" :index="item.cnName">
                    <template slot="title">
                        <i :class="item.icon + ' ais-aside-icon-self'"></i>
                        <span>{{item.cnName}}</span>
                    </template>
                    <el-menu-item-group>
                        <div v-for="subItem in item.children" :key="subItem.cnName">
                            <el-submenu v-if="subItem.children && subItem.children.length > 0"
                                :index="subItem.cnName">
                                <template slot="title">
                                    <span>{{subItem.cnName}}</span>
                                </template>
                                <el-menu-item-group>
                                    <el-menu-item v-for="(single, index) in subItem.children"
                                        :key="single.cnName + index" :index="single.cnName">{{single.cnName}}
                                    </el-menu-item>
                                    <!-- <span slot="title">{{subItem.cnName}}</span> -->
                                </el-menu-item-group>
                            </el-submenu>
                            <el-menu-item v-else :key="subItem.cnName" :index="subItem.cnName">
                                <span slot="title">{{subItem.cnName}}</span>
                            </el-menu-item>
                        </div>
                    </el-menu-item-group>
                </el-submenu>
            </div>
        </el-menu>
    </div>
</template>
<script>
    export default {
        name: "ais-aside",
        props: {
            isCollapse: {
                type: Boolean,
                default: false
            },
            routerArray: {
                type: Array,
                default: () => [{
                        path: "/main/selfBody/finaReco",
                        cnName: "财报识别",
                        icon: "el-icon-s-order",
                        children: []
                    },
                    {
                        path: "/main/selfBody/paramsConfig",
                        cnName: "参数配置",
                        icon: "el-icon-s-grid",
                        children: []
                    }
                ]
            },
        },
        data() {
            return {

            }
        },
        methods: {
            handleOpen(key, keyPath) {
                this.$emit("handleOpen", key, keyPath)
            },
            handleClose(key, keyPath) {
                this.$emit("handleClose", key, keyPath)
            },
        }
    }
</script>

<style scoped>
    .slide-bar>>>.el-menu-item {
        line-height: 54px;
    }

    .el-menu-vertical-demo.el-menu {
        height: auto;
    }

    ::-webkit-scrollbar {
        width: 0px;
    }

    .el-menu-vertical-demo:not(.el-menu--collapse) {
        width: 200px;
        height: 100%;
    }

    .el-menu-container {
        display: inline-block;
    }

    .el-menu-vertical-demo {
        text-align: left;
    }

    .logo-image {
        width: 9rem;
        height: 2.6rem;
        padding: 0.4rem 0 0.4rem 1.5rem;
    }

    .slide-bar {
        height: 100%;
    }

    .slide-bar>>>.el-submenu__title {
        background-color: transparent;
    }

    .slide-bar>>>.slide-bar-icon-self {
        color: #50A9FF
    }

    .bottom-image {
        /* background-image: url('/static/img/slidelogo.4e07824.png'); */
        height: 18rem;
        bottom: 0;
        position: absolute;
        width: 100%;
        background-size: cover;
    }
</style>