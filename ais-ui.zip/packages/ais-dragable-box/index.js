import AisDragBox from './ais-dragable-box.vue';

AisDragBox.install = function(Vue) {
    Vue.component(AisDragBox.name, AisDragBox);
}

export default AisDragBox;