<template>
    <div class="drag-box" :style="dragBoxStyle" :ref="refName">
        <slot name="content">default content</slot>
    </div>
</template>


<script>
    export default {
        name: "ais-drag-box",
        props: {
            //拖拽盒子宽度
            width: {
                type: String,
                default: () => {
                    return "300px"
                }
            },
            //拖拽盒子高度
            height: {
                type: String,
                default: () => {
                    return "300px"
                }
            },
            //拖拽盒子左边距
            leftPosition: {
                type: String,
                default: () => {
                    return "0px"
                }
            },
            //拖拽盒子顶部边距
            topPosition: {
                type: String,
                default: () => {
                    return "0px"
                }
            },
            //是否显示
            isShow: {
                type: Boolean,
                default: () => {
                    return false
                }
            },
            //ref名称
            refName: {
                type: String,
                default: () => {
                    return "dragbox" + new Date().getTime()
                }
            },
            //拖拽盒子内部不能拖拽的部分,传入类名
            unDragPart: {
                type: String,
                default: () => {
                    return "I HAVE NO K"
                }
            }
        },
        data() {
            return {
                dragBoxStyle: {
                    width: this.width,
                    height: this.height,
                    left: this.leftPosition,
                    top: this.topPosition,
                    display: this.isShow ? "block" : "none"
                }
            }
        },
        mounted() {
            this.dragFloatingBox()
        },
        methods: {
            /**
             * @author chensonglin
             * @description 使元素可以拖拽
             */
            dragFloatingBox() {
                let _this = this
                const floatingBox = this.$refs[this.refName]; // 获取悬浮框元素

                let initialMouseX = 0; // 初始鼠标位置的变量
                let initialMouseY = 0;
                let initialBoxX = 0; // 初始悬浮框位置的变量
                let initialBoxY = 0;

                floatingBox.addEventListener("mousedown", (event) => {
                    initialMouseX = event.clientX;
                    initialMouseY = event.clientY;
                    initialBoxX = floatingBox.offsetLeft;
                    initialBoxY = floatingBox.offsetTop;

                    document.addEventListener("mousemove", dragElement);
                    document.addEventListener("mouseup", stopDragging);
                });

                const inputField = floatingBox.querySelector(this.unDragPart);
                if (inputField) {
                    inputField.addEventListener("mousedown", (event) => {
                        event.stopPropagation();
                    });
                }
                function dragElement(event) {
                    event.preventDefault()
                    const deltaX = event.clientX - initialMouseX;
                    const deltaY = event.clientY - initialMouseY;
                    const newBoxX = initialBoxX + deltaX;
                    const newBoxY = initialBoxY + deltaY;
                    floatingBox.style.left = newBoxX + "px";
                    floatingBox.style.top = newBoxY + "px";
                    _this.offsetX = newBoxX
                    _this.offsetY = newBoxY
                }

                function stopDragging() {
                    document.removeEventListener("mousemove", dragElement);
                    document.removeEventListener("mouseup", stopDragging);
                }
            }
        }
    }
</script>


<style lang="scss" scoped>
    .drag-box {
        display: none;
        position: fixed;
        border: 1px solid #ccc;
        border-radius: 4px;
        background: white;
        cursor: all-scroll;
    }
</style>